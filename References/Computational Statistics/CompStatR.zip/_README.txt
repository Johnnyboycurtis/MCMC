See the file CompStatR.pdf
